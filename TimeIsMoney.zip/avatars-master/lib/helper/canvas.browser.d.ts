export declare function createCanvas(): HTMLCanvasElement;
export declare function createImage(): HTMLImageElement;
