import Avatars from './avatars';
export default Avatars;
