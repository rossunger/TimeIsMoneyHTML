declare var avatars: any;
