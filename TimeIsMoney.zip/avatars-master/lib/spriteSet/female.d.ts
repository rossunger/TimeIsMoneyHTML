import { SpriteSetInterface } from '../spriteSet';
declare let femaleSpriteSet: SpriteSetInterface;
export default femaleSpriteSet;
