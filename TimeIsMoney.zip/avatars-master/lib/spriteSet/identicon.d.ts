import { SpriteSetInterface } from '../spriteSet';
declare let identiconSpriteSet: SpriteSetInterface;
export default identiconSpriteSet;
