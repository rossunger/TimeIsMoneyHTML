import { SpriteSetInterface } from '../spriteSet';
declare let maleSpriteSet: SpriteSetInterface;
export default maleSpriteSet;
