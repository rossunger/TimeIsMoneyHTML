# Version 1.x to 2.x

* `Callbacks` were replaced by `Promises`. (See README.md)
* The option object is completely omitted. The resize method can now be used to change the size. (See README.md)
* `Chance.js` has been replaced by seedrandom.
* `async` has been completely removed.
* All dependencies are now included in `avatars.js`. The `avatars.pack.js` does not exists anymore.
* New identicon sprite set.
