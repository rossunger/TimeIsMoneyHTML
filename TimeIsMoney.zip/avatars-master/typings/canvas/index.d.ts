declare module 'canvas';
