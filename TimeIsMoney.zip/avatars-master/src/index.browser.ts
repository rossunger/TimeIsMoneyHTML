var avatars = require('./avatars').default;

module.exports = avatars;
